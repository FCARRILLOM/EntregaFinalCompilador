Equipo Obj7
Fernando Carrillo
Lucia Cantu-Miller

Avances:
- 08/04/21 Implementación de tokens y gramática descritos en el documento con los diagramas

Pendiente:
- Investigar y arreglar warnings de shift/reduce reduce/reduce

Cambios personales a la descripcioó original
- En lugar de llamar los tipos en español 'entero, flotante', se cambiaron a inglés 'int, float'
- En lugar de declarar las variables como 'ids : tipo', se cambio el orden a 'tipo : ids'


Para correr el parser:
- Abrir la terminal y navegar al folder donde se encuentra el código
- Correr el comando 'make' para generar el ejecutable 'parser'
- Insertar un documento txt al parser corriendo el comando './parser < (tuArchivo).txt'
- Si hay un error sintáctico en el código, aparecerá un mensaje de error indicando la linea donde se encuentra este

