#include "Quad.h"
#include <iostream>

void Quad::addQuad(const std::vector<std::string> tempQuad) {
    quads.push_back(tempQuad);
    quadPtr++;
}

void Quad::addArithmeticQuad() {
    std::string right_operand = sOperands.back();
    sOperands.pop_back();
    std::string right_type = sTypes.back();
    sTypes.pop_back();

    std::string left_operand = sOperands.back();
    sOperands.pop_back();
    std::string left_type = sTypes.back();
    sTypes.pop_back();

    std::string op = sOperators.back();
    sOperators.pop_back();

    std::string resultType = cubo.getTypeFromCube(left_type, right_type, op);
    //std::cout << left_operand << ":" << left_type << ", " << right_operand << ":" << right_type << ", " << op << ", " << resultType << std::endl;
    if (resultType.substr(0, 3) != "err") {
        std::string result = getNextAvail();
        std::vector<std::string> tempQuad {op, left_operand, right_operand, result};
        addQuad(tempQuad);
        sOperands.push_back(result);
        sTypes.push_back(resultType);
        // If any operand were a temporal space, return it to AVAIL ???
    } else {
        std::cout << resultType << std::endl;
    }
}

void Quad::addAssignQuad() {
    std::string op = sOperators.back();
    sOperators.pop_back();

    std::string res = sOperands.back();
    sOperands.pop_back();
    std::string res_type = sTypes.back();
    sTypes.pop_back();

    std::string left_operand = sOperands.back();
    sOperands.pop_back();
    std::string left_type = sTypes.back();
    sTypes.pop_back();

    std::string assignType = cubo.getTypeFromCube(left_type, res_type, op);
    if (assignType.substr(0, 3) != "err") {
        std::vector<std::string> tempQuad {op, res, "-", left_operand};
        addQuad(tempQuad);
    } else {
        std::cout << assignType << std::endl;
    }
}

std::string Quad::getNextAvail() {
    avail.push_back("t" + std::to_string(availCounter++));
    return avail.back();
}

void Quad::fillGotoQuad(int position, int newValue) {
    quads[position][3] = std::to_string(newValue);
}

void Quad::clearQuad() {
    printData();
    sOperators.clear();
    sOperands.clear();
    sTypes.clear();
    quads.clear();
    avail.clear();
    availCounter = 1;
    quadPtr = 0;
}

// REGLAS ARITMETICAS

// 1
void Quad::addOperand(const std::string name, std::string type) {
    sOperands.push_back(name);
    sTypes.push_back(type);
}

// 2
void Quad::addOperatorPlusMinus(const std::string op) {
    sOperators.push_back(op);
}

// 3
void Quad::addOperatorMultDiv(const std::string op) {
    sOperators.push_back(op);
}

// 4
void Quad::removeFromStackPlusMinus() {
    if (sOperators.empty()) return;

    if (sOperators.back() == "+" || sOperators.back() == "-") {
        addArithmeticQuad();
    }
}

// 5
void Quad::removeFromStackMultDiv() {
    if (sOperators.empty()) return;

    if (sOperators.back() == "*" || sOperators.back() == "/") {
        addArithmeticQuad();
    }
}

// 6
void Quad::addFalseBottom() {
    sOperators.push_back("[");
}

// 7
void Quad::removeFalseBottom() {
    sOperators.pop_back();
}

// 8
void Quad::addOperatorRel(const std::string op) {
    sOperators.push_back(op);
}

// 9
void Quad::removeFromStackRel() {
    if (sOperators.empty()) return;
    
    std::string relOps = ">,<,>=,<=,<>,==";
    if (relOps.find(sOperators.back()) != std::string::npos) {
        addArithmeticQuad();
    }
}

// 10
void Quad::addOperatorAnd(const std::string op) {
    sOperators.push_back(op);
}

// 11
void Quad::addOperatorOr(const std::string op) {
    sOperators.push_back(op);
}

// 12
void Quad::removeFromStackAnd() {
    if (sOperators.empty()) return;

    if (sOperators.back() == "&") {
        addArithmeticQuad();
    }
}

// 13
void Quad::removeFromStackOr() {
    if (sOperators.empty()) return;

    if (sOperators.back() == "|") {
        addArithmeticQuad();
    }
}

// 14
void Quad::addOperatorAsig(const std::string op) {
    sOperators.push_back(op);
}

// 15
void Quad::removeFromStackAssign() {
    if (sOperators.empty()) return;

    if (sOperators.back() == "=") {
        addAssignQuad();
    } 
}

// LECTURA Y ESCRITURA
// 16
void Quad::addRead(const std::string name) {
    // Verificar que variable 'name' exista en tabla de variables
    std::vector<std::string> tempQuad {"read", "-", "-", name};
    addQuad(tempQuad);
}

// 17
void Quad::addWriteExp() {
    if (sOperands.empty()) {
        std::cout << "Write EXP error: no operands left\n";
        return;
    }
    std::string res = sOperands.back();
    sOperands.pop_back();

    std::vector<std::string> tempQuad {"write", "-", "-", res};
    addQuad(tempQuad);
}

// 18
void Quad::addWriteStr(const std::string const_string) {
    std::vector<std::string> tempQuad {"write", "-", "-", const_string}; 
    addQuad(tempQuad);
}

// DECISIONES
// 1
void Quad::addGotoIf() {
    std::string expType = sTypes.back();
    sTypes.pop_back();

    if (expType != "bool") {
        std::cout << "err: decision expresion is not type 'bool'\n";
    } else {
        std::string result = sOperands.back();
        sOperands.pop_back();

        std::vector<std::string> tempQuad {"GotoF", result, "-", "_"}; 
        addQuad(tempQuad);

        sJumps.push_back(quadPtr-1);
    }
}

// 2
void Quad::addDecisionEnd() {
    int end = sJumps.back();
    sJumps.pop_back();

    fillGotoQuad(end, quadPtr);
}

// 3
void Quad::addGotoElse() {
    std::vector<std::string> tempQuad {"GOTO", "-", "-", "_"}; 
    addQuad(tempQuad);

    int falseLoc = sJumps.back();
    sJumps.pop_back();

    sJumps.push_back(quadPtr-1);

    fillGotoQuad(falseLoc, quadPtr);
}

// CONDICIONALES
// 1
void Quad::addWhileCheckpoint() {
    sJumps.push_back(quadPtr);
}

// 2
void Quad::addGotoWhile() {
    std::string expType = sTypes.back();
    sTypes.pop_back();

    if (expType != "bool") {
        std::cout << "err: conditional expresion is not type 'bool'\n";
    } else {
        std::string result = sOperands.back();
        sOperands.pop_back();

        std::vector<std::string> tempQuad {"GotoF", result, "-", "_"}; 
        addQuad(tempQuad);

        sJumps.push_back(quadPtr-1);
    }
}

// 3
void Quad::addConditionalEnd() {
    int end = sJumps.back();
    sJumps.pop_back();

    int returnStart = sJumps.back();
    sJumps.pop_back();

    std::vector<std::string> tempQuad {"GOTO", "-", "-", std::to_string(returnStart)}; 
    addQuad(tempQuad);

    fillGotoQuad(end, quadPtr); 
}

// NO CONDICIONALES
// 1
void Quad::addLoopCounter(const std::string counterId) {
    std::string counterType = sTypes.back();
    sTypes.pop_back();

    if (counterType != "int") {
        std::cout << "err: loop counter not of type 'int'\n";
    } else {
        std::string counterExp = sOperands.back();
        sOperands.pop_back();

        std::vector<std::string> tempQuad {"=", counterExp, "-", counterId}; 
        addQuad(tempQuad);

        sOperands.push_back(counterId);
        sTypes.push_back("int");
    }
}

// 2
void Quad::addLoopLimit() {
    std::string limitType = sTypes.back();
    sTypes.pop_back();

    if (limitType != "int") {
        std::cout << "err: loop counter limit not of type 'int'\n";
    } else {
        std::string limitExp = sOperands.back();
        sOperands.pop_back();

        std::string counterId = sOperands.back();
        sOperands.pop_back();
        std::string counterType = sTypes.back();
        sTypes.pop_back();

        sJumps.push_back(quadPtr);

        std::string result = getNextAvail();
        std::vector<std::string> tempQuad {"<", counterId, limitExp, result}; 
        addQuad(tempQuad);

        sOperands.push_back(result);
        sTypes.push_back("bool");
    }
}

// 3
void Quad::addGotoFor() {
    std::string resultType = sTypes.back();
    sTypes.pop_back();

    if (resultType != "bool") {
        std::cout << "err: loop expresion not of type 'bool'\n";
    } else {
        std::string result = sOperands.back();
        sOperands.pop_back();

        std::vector<std::string> tempQuad {"GotoF", result, "-", "_"}; 
        addQuad(tempQuad);
        sJumps.push_back(quadPtr - 1);
    }
}

// 4
void Quad::addNonConditionalEnd(const std::string counterId) {
    int end = sJumps.back();
    sJumps.pop_back();

    int returnStart = sJumps.back();
    sJumps.pop_back();

    // increment for loop counter by 1
    std::string result = getNextAvail();
    std::vector<std::string> tempQuad {"+", counterId, "1", result}; 
    addQuad(tempQuad);
    tempQuad = std::vector<std::string> {"=", result, "-", counterId}; 
    addQuad(tempQuad);

    tempQuad = std::vector<std::string> {"GOTO", "-", "-", std::to_string(returnStart)}; 
    addQuad(tempQuad);

    fillGotoQuad(end, quadPtr); 
}


void Quad::printData() {
    int quadCounter = 0;

    for (auto quad : quads) {
        std::cout << quadCounter++ << " " << quad[0] <<  ", " << quad[1] <<  ", " << quad[2] <<  ", " << quad[3] <<  "\n";
    }
    std::cout << "Operators left in stack: " << sOperators.size() << " - ";
    while(!sOperators.empty()) {
        std::cout << sOperators.back() << ", ";
        sOperators.pop_back();
    }
    std::cout << "Operands left in stack: " << sOperands.size() << " - ";
    while(!sOperands.empty()) {
        std::cout << sOperands.back() << ", ";
        sOperands.pop_back();
    }
    std::cout << "\nQuad ptr: " << quadPtr << "\n";
    std::cout << "\n---------\n";
}