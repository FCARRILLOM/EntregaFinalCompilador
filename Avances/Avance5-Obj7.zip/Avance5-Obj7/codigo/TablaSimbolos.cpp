#include "TablaSimbolos.h"
#include <iostream>

int TablaSimbolos::funcExists(const std::string funcId) {
   return(funcDir.count(funcId));
}

// 1
void TablaSimbolos::createFunc(const std::string funcId, const std::string returnType) {
   if (funcExists(funcId)) { 
      std::cout << "Duplicate function name\n"; 
      return;
   }
   funcDir[funcId] = FuncEntry {funcId, returnType, std::vector<std::string>(), 0, 0, -1,
                                 std::make_unique<std::unordered_map<std::string, VarEntry>>()};
}

void TablaSimbolos::addVarsToDir(std::string funcId, std::vector<VarEntry> vars) {
   // mapea todas las variables dentro del directorio de variables
   if (funcDir[funcId].varDir == nullptr) {
      std::cout << "ERROR: Empty variable directory for function: " << funcId << "\n";
      return;
   }

   for (VarEntry var : vars) {
     (*funcDir[funcId].varDir)[var.varName] = var;
   }
}

///// VARIABLES DECLARADAS DENTRO DEL BLOQUE (variables ...) /////
void TablaSimbolos::initVarsForDir() {
   currVarNames.clear(); 
   varsForDir.clear();         
}

void TablaSimbolos::addToCurrVarNames(const std::string varName) {
   currVarNames.push_back(varName);
}

void TablaSimbolos::saveCurrVars(const std::string varType) {
   for (std::string varName : currVarNames) {
     varsForDir.push_back(VarEntry {varName, varType});
   }
   currVarNames.clear();
}

///// VARIABLES DECLARADAS COMO PARAMETROS EN FUNCIONES /////
void TablaSimbolos::initParameterVars() {
   parameters.clear();
}

void TablaSimbolos::addParameterVar(std::string varName, std::string varType) {
   parameters.push_back(VarEntry {varName, varType});
}

// DEFINICIONES DE FUNCIONES
// 2/3
void TablaSimbolos::addParameterVarsToDir(const std::string funcId) {
  addVarsToDir(funcId, parameters);
  // add parameter types to Parameter table
  for (VarEntry par : parameters) {
     // insert as a stack
     funcDir[funcId].parameterTable.insert(funcDir[funcId].parameterTable.begin(), par.varType);
   }
}

// 4
void TablaSimbolos::addNumParameters(const std::string funcId) {
   funcDir[funcId].numPar = parameters.size();
}

// 5 from FUNCIONES
void TablaSimbolos::addCurrVarsToDir(const std::string funcId) {
   addVarsToDir(funcId, varsForDir);
   funcDir[funcId].numLVar = varsForDir.size();
}

// 6
void TablaSimbolos::addFuncCont(const std::string funcId, const Quad &quad) {
   funcDir[funcId].quadCont = quad.getQuadCont();
}

// 7
void TablaSimbolos::addEndFunc(const std::string funcId, Quad &quad) {
   funcDir[funcId].varDir.reset();
   quad.addEndFunc();
}

// LLAMADAS DE FUNCIONES
// 1
void TablaSimbolos::verifyFunction(const std::string funcId) {
   if (funcDir.count(funcId) == 0) {
      std::cout << "ERROR: " + funcId + " no existe\n";
   }
   currentFunctionCall = funcId;
}

// 2
void TablaSimbolos::generateEra(Quad &quad) {
   parameterCounter = 0;
   quad.generateEra(currentFunctionCall);
}

// 3
void TablaSimbolos::verifyParameterType(Quad &quad) {
   std::string argument = quad.popOperand();
   std::string argumentType = quad.popType();

   if (parameterCounter < funcDir[currentFunctionCall].parameterTable.size()) {
      if (argumentType != funcDir[currentFunctionCall].parameterTable[parameterCounter]) {
         std::cout << "ERROR: mismatching parameter types for func '" + currentFunctionCall + "'\n";
         std::cout << "Given type: " + argumentType + ", expected type: " + funcDir[currentFunctionCall].parameterTable[parameterCounter] + "\n";
         return;
      }
      
      quad.generateParameter(argument, "param" + std::to_string(parameterCounter));

   } else {
      std::cout << "ERROR: extraneous parameters for func '" + currentFunctionCall + "'\n";
   }
}

// 4
void TablaSimbolos::moveToNextParam(){
   parameterCounter += 1;
}

// 5
void TablaSimbolos::verifyLastParam(){
   if (parameterCounter > funcDir[currentFunctionCall].parameterTable.size()) {
      std::cout << "ERROR: coherence in number of parameters for function call '" + currentFunctionCall + "'\n";
   }
}

// 6
void TablaSimbolos::addGoSub(Quad &quad){
   quad.addGoSub(currentFunctionCall, funcDir[currentFunctionCall].quadCont);
}


void TablaSimbolos::printData() {
   std::cout << "FuncDir\n";
   for (auto &f_entry : funcDir) {

     std::cout << f_entry.second.quadCont << " " << f_entry.first << ": " << f_entry.second.returnType << "\n";
     std::cout << "Signature (" << f_entry.second.numPar << " params): ";
     for (std::string par : f_entry.second.parameterTable) {
        std::cout << par << ", ";
     }

     std::cout << "\nLocal vars (" << f_entry.second.numLVar << ") - ";
     /*
     if (f_entry.second.varDir) {
       std::cout << "Local vars (" << f_entry.second.numLVar << ") - ";
       for (auto &v_entry : *(f_entry.second.varDir)) {
         std::cout << v_entry.second.varType << ": " << v_entry.second.varName << ", ";
       }
     }
     */
     std::cout << "\n\n";
   }
   
}
