#include "Quad.h"
#include <iostream>
#include <fstream>

void Quad::addQuad(const std::vector<std::string> tempQuad) {
    quads.push_back(tempQuad);

    int opCode = cubo.operatorMap[tempQuad[0]];
    std::vector<std::string> memQuad = tempQuad;
    // gosub, goto, era, endfunc, end. stay the same
    if (opCode == 15 || opCode == 16 || opCode == 17 || opCode == 18 || opCode == 22)  {
        // 
    } else if (opCode == 13) { // parameters
        memQuad[1] = getVariableAddress(tempQuad[1]);
    } else if (opCode == 19) { // write
        if (tempQuad[3][0] != '"') // ignore strings
            memQuad[3] = getVariableAddress(tempQuad[3]);
    } else if (opCode == 20) { // read
        memQuad[3] = getVariableAddress(tempQuad[3]);
    } else if (opCode == 21) { // return
        // look for function's memory address in global variables table
        memQuad[1] = std::to_string((*(*tablasDatos).funcDir[(*tablasDatos).programName].varDir)[tempQuad[1]].memoryAddr);
        memQuad[3] = getVariableAddress(tempQuad[3]);
    } else {
        if (tempQuad[1] != "-") memQuad[1] = getVariableAddress(tempQuad[1]);

        if (tempQuad[2] != "-") memQuad[2] = getVariableAddress(tempQuad[2]);

        if (tempQuad[3] != "-") memQuad[3] = getVariableAddress(tempQuad[3]);
    }
    memQuad[0] = std::to_string(cubo.operatorMap[tempQuad[0]]);
    memQuads.push_back(memQuad);

    quadPtr++;
}

void Quad::addArithmeticQuad() {
    std::string right_operand = sOperands.back();
    sOperands.pop_back();
    std::string right_type = sTypes.back();
    sTypes.pop_back();

    std::string left_operand = sOperands.back();
    sOperands.pop_back();
    std::string left_type = sTypes.back();
    sTypes.pop_back();

    std::string op = sOperators.back();
    sOperators.pop_back();

    std::string resultType = cubo.getTypeFromCube(left_type, right_type, op);
    if (resultType.substr(0, 3) != "err") {
        std::string result = getNextAvail(resultType);
        // memory: local or global, resultType, temp
        std::vector<std::string> tempQuad {op, left_operand, right_operand, result};
        addQuad(tempQuad);
        sOperands.push_back(result);
        sTypes.push_back(resultType);
        // TODO: If any operand were a temporal space, return it to AVAIL ???
    } else {
        std::cout << resultType << std::endl;
    }
}

void Quad::addAssignQuad() {
    std::string op = sOperators.back();
    sOperators.pop_back();

    std::string res = sOperands.back();
    sOperands.pop_back();
    std::string res_type = sTypes.back();
    sTypes.pop_back();

    std::string left_operand = sOperands.back();
    sOperands.pop_back();
    std::string left_type = sTypes.back();
    sTypes.pop_back();

    std::string assignType = cubo.getTypeFromCube(left_type, res_type, op);
    if (assignType.substr(0, 3) != "err") {
        std::vector<std::string> tempQuad {op, res, "-", left_operand};
        addQuad(tempQuad);
    } else {
        std::cout << "ERROR: cannot assign " + left_operand + " = " + res + "\n";
        std::cout << assignType << std::endl;
    }
}

std::string Quad::getNextAvail(const std::string type) {
    if (sTemps.empty()) {
        std::cout << "ERROR: empty temporal counter for avail\n";
        return "err";
    }

    std::string avail =  "t" + std::to_string(sTemps.back());
    sTemps.back() += 1;

    int tempType = cubo.typeMap[type];
    std::string currentFunc = (*tablasDatos).currentFunc;
    std::vector<int> &tempTypes = sTempTypes.back();
    tempTypes[tempType]++;

    // add temp memory to var tables
    int memAddr = -1;
    std::string scope = "local";
    if (currentFunc == "main") scope = "global";

    switch (tempType) {
        case 0: // int
            memAddr = memoria->reserveIntMemory(scope, true);
            break;
        case 1: // float
            memAddr = memoria->reserveFloatMemory(scope, true);
            break;
        case 3: // bool
            memAddr = memoria->reserveBoolMemory(scope);
            break;
    }

    VarEntry var { avail, type, memAddr };
    if (currentFunc == "main") {
        (*(*tablasDatos).funcDir[(*tablasDatos).programName].varDir)[avail] = var;
    } else {
        (*(*tablasDatos).funcDir[currentFunc].varDir)[avail] = var;
    }

    return avail;
}

void Quad::fillGotoQuad(int position, int newValue) {
    quads[position][3] = std::to_string(newValue);
    memQuads[position][3] = std::to_string(newValue);
}

std::string Quad::getVariableAddress(const std::string name) {
    std::string currentFunc = (*tablasDatos).currentFunc;
    std::string programName = (*tablasDatos).programName;

    int addr = -1;
    if ((*tablasDatos).constDir.count(name) > 0) { // const table
        addr = (*tablasDatos).constDir[name];
    } else if (currentFunc != "main"  && (*(*tablasDatos).funcDir[currentFunc].varDir).count(name) > 0) { // local vars
        addr = (*(*tablasDatos).funcDir[currentFunc].varDir)[name].memoryAddr;
    } else if (programName != "" && (*(*tablasDatos).funcDir[programName].varDir).count(name) > 0) { // global vars
        addr = (*(*tablasDatos).funcDir[programName].varDir)[name].memoryAddr;
    } else {
        std::cout << "ERROR: variable lookup for '" + name + "' not found\n";
    }
    return std::to_string(addr);
}

void Quad::generateIntermediateCode() {
    std::ofstream outFile;
    outFile.open("codigo.cmm");
    // func dir
    for (auto &entry : (*tablasDatos).funcDir) {
        int totalMemSize = 0;
        FuncEntry &funcData = entry.second;
        outFile << entry.first << ", " << funcData.quadCont << ", ";
        // local vars used
        outFile << funcData.numLVar[0] << ", ";
        outFile << funcData.numLVar[1] << ", ";
        outFile << funcData.numLVar[2] << ", ";
        outFile << funcData.numLVar[3] << ", ";
        // temps used
        outFile << funcData.numTemp[0] << ", ";
        outFile << funcData.numTemp[1]<< ", ";
        outFile << funcData.numTemp[3] << "\n";
    }

    // const table
    outFile << "%%\n";
    for (auto entry : (*tablasDatos).constDir) {
        outFile << entry.first << ", " << entry.second << "\n";
    }

    // quads
    outFile << "%%\n";
    for (auto quad : memQuads) {
        outFile << quad[0] << ", " << quad[1] << ", " << quad[2] << ", " << quad[3] << "\n";
    }
    outFile.close();

}

void Quad::clearQuad() {
    addQuad({"END", "-", "-", "-"});
    printData();
    generateIntermediateCode();
    sOperators.clear();
    sOperands.clear();
    sTypes.clear();
    quads.clear();
    sTemps.clear();
    sTempTypes.clear();
    quadPtr = 0;
}

// REGLAS ARITMETICAS

// 1
void Quad::addOperand(const std::string name) {
    std::string currentFunc = (*tablasDatos).currentFunc;
    std::string programName = (*tablasDatos).programName;

    // look for vairable type in var tables
    std::string type = "int";
    if (currentFunc != "main"  && (*(*tablasDatos).funcDir[currentFunc].varDir).count(name) > 0) { // local
        type = (*(*tablasDatos).funcDir[currentFunc].varDir)[name].varType;
    } else if ((*(*tablasDatos).funcDir[programName].varDir).count(name) > 0) { // global
        type = (*(*tablasDatos).funcDir[programName].varDir)[name].varType;
    } else {
        std::cout << "ERROR: variable '" + name + "' not found\n";
    }
    
    sOperands.push_back(name);
    sTypes.push_back(type);
}

// 2
void Quad::addOperatorPlusMinus(const std::string op) {
    sOperators.push_back(op);
}

// 3
void Quad::addOperatorMultDiv(const std::string op) {
    sOperators.push_back(op);
}

// 4
void Quad::removeFromStackPlusMinus() {
    if (sOperators.empty()) return;

    if (sOperators.back() == "+" || sOperators.back() == "-") {
        addArithmeticQuad();
    }
}

// 5
void Quad::removeFromStackMultDiv() {
    if (sOperators.empty()) return;

    if (sOperators.back() == "*" || sOperators.back() == "/") {
        addArithmeticQuad();
    }
}

// 6
void Quad::addFalseBottom() {
    sOperators.push_back("[");
}

// 7
void Quad::removeFalseBottom() {
    sOperators.pop_back();
}

// 8
void Quad::addOperatorRel(const std::string op) {
    sOperators.push_back(op);
}

// 9
void Quad::removeFromStackRel() {
    if (sOperators.empty()) return;
    
    std::string relOps = ">,<,>=,<=,<>,==";
    if (relOps.find(sOperators.back()) != std::string::npos) {
        addArithmeticQuad();
    }
}

// 10
void Quad::addOperatorAnd(const std::string op) {
    sOperators.push_back(op);
}

// 11
void Quad::addOperatorOr(const std::string op) {
    sOperators.push_back(op);
}

// 12
void Quad::removeFromStackAnd() {
    if (sOperators.empty()) return;

    if (sOperators.back() == "&") {
        addArithmeticQuad();
    }
}

// 13
void Quad::removeFromStackOr() {
    if (sOperators.empty()) return;

    if (sOperators.back() == "|") {
        addArithmeticQuad();
    }
}

// 14
void Quad::addOperatorAsig(const std::string op) {
    sOperators.push_back(op);
}

// 15
void Quad::removeFromStackAssign() {
    if (sOperators.empty()) return;

    if (sOperators.back() == "=") {
        addAssignQuad();
    } 
}

// CONSTANTES
// 1
void Quad::addConstOperand(const std::string value, const std::string type) {
    sOperands.push_back(value);
    sTypes.push_back(type);

    // add to const table;
    if ((*tablasDatos).constDir.count(value) > 0) return;

    int memAddr = -1;
    if (type == "int") {
        memAddr = memoria->reserveIntMemory("const", false);
    } else if (type == "float") {
        memAddr = memoria->reserveFloatMemory("const", false);
    } else if (type == "char") {
        memAddr = memoria->reserveCharMemory("const");
    }
    
    if (memAddr == -1) {
        std::cout << "ERROR: cannot reserve memory for const " +  value + " \n";
    }

    (*tablasDatos).constDir[value] = memAddr;
}

// LECTURA Y ESCRITURA
// 16
void Quad::addRead(const std::string name) {
    std::vector<std::string> tempQuad {"read", "-", "-", name};
    addQuad(tempQuad);
}

// 17
void Quad::addWriteExp() {
    if (sOperands.empty()) {
        std::cout << "Write EXP error: no operands left\n";
        return;
    }
    std::string res = sOperands.back();
    sOperands.pop_back();

    std::vector<std::string> tempQuad {"write", "-", "-", res};
    addQuad(tempQuad);
}

// 18
void Quad::addWriteStr(const std::string const_string) {
    std::vector<std::string> tempQuad {"write", "-", "-", const_string}; 
    addQuad(tempQuad);
}

// DECISIONES
// 1
void Quad::addGotoIf() {
    std::string expType = sTypes.back();
    sTypes.pop_back();

    if (expType != "bool") {
        std::cout << "ERROR: decision expresion is not type 'bool'\n";
    } else {
        std::string result = sOperands.back();
        sOperands.pop_back();

        std::vector<std::string> tempQuad {"GotoF", result, "-", "-"}; 
        addQuad(tempQuad);

        sJumps.push_back(quadPtr-1);
    }
}

// 2
void Quad::addDecisionEnd() {
    int end = sJumps.back();
    sJumps.pop_back();

    fillGotoQuad(end, quadPtr);
}

// 3
void Quad::addGotoElse() {
    std::vector<std::string> tempQuad {"GOTO", "-", "-", "-"}; 
    addQuad(tempQuad);

    int falseLoc = sJumps.back();
    sJumps.pop_back();

    sJumps.push_back(quadPtr-1);

    fillGotoQuad(falseLoc, quadPtr);
}

// CONDICIONALES
// 1
void Quad::addWhileCheckpoint() {
    sJumps.push_back(quadPtr);
}

// 2
void Quad::addGotoWhile() {
    std::string expType = sTypes.back();
    sTypes.pop_back();

    if (expType != "bool") {
        std::cout << "ERROR: conditional expresion is not type 'bool'\n";
    } else {
        std::string result = sOperands.back();
        sOperands.pop_back();

        std::vector<std::string> tempQuad {"GotoF", result, "-", "-"}; 
        addQuad(tempQuad);

        sJumps.push_back(quadPtr-1);
    }
}

// 3
void Quad::addConditionalEnd() {
    int end = sJumps.back();
    sJumps.pop_back();

    int returnStart = sJumps.back();
    sJumps.pop_back();

    std::vector<std::string> tempQuad {"GOTO", "-", "-", std::to_string(returnStart)}; 
    addQuad(tempQuad);

    fillGotoQuad(end, quadPtr); 
}

// NO CONDICIONALES
// 1
void Quad::addLoopCounter(const std::string counterId) {
    std::string counterType = sTypes.back();
    sTypes.pop_back();

    if (counterType != "int") {
        std::cout << "ERROR: loop counter not of type 'int'\n";
    } else {
        std::string counterExp = sOperands.back();
        sOperands.pop_back();

        // add counter as local variable
        int memAddr = memoria->reserveIntMemory("local", false);
        std::string currentFuncDecl = (*tablasDatos).currentFunc;
        VarEntry var {counterId, "int", memAddr};
        (*(*tablasDatos).funcDir[currentFuncDecl].varDir)[counterId] = var;
        (*tablasDatos).funcDir[currentFuncDecl].numLVar[0] += 1;

        std::vector<std::string> tempQuad {"=", counterExp, "-", counterId}; 
        addQuad(tempQuad);

        sOperands.push_back(counterId);
        sTypes.push_back("int");
    }
}

// 2
void Quad::addLoopLimit() {
    std::string limitType = sTypes.back();
    sTypes.pop_back();

    if (limitType != "int") {
        std::cout << "ERROR: loop counter limit not of type 'int'\n";
    } else {
        std::string limitExp = sOperands.back();
        sOperands.pop_back();

        std::string counterId = sOperands.back();
        sOperands.pop_back();
        std::string counterType = sTypes.back();
        sTypes.pop_back();

        sJumps.push_back(quadPtr);

        std::string result = getNextAvail("bool");
        // memory: temp, bool, 
        std::vector<std::string> tempQuad {"<=", counterId, limitExp, result}; 
        addQuad(tempQuad);

        sOperands.push_back(result);
        sTypes.push_back("bool");
    }
}

// 3
void Quad::addGotoFor() {
    std::string resultType = sTypes.back();
    sTypes.pop_back();

    if (resultType != "bool") {
        std::cout << "ERROR: loop expresion not of type 'bool'\n";
    } else {
        std::string result = sOperands.back();
        sOperands.pop_back();

        std::vector<std::string> tempQuad {"GotoF", result, "-", "-"}; 
        addQuad(tempQuad);
        sJumps.push_back(quadPtr - 1);
    }
}

// 4
void Quad::addNonConditionalEnd(const std::string counterId) {
    int end = sJumps.back();
    sJumps.pop_back();

    int returnStart = sJumps.back();
    sJumps.pop_back();

    // increment for loop counter by 1
    std::string result = getNextAvail("int");
    // memory:
    std::vector<std::string> tempQuad {"+", counterId, "1", result}; 
    addQuad(tempQuad);
    tempQuad = std::vector<std::string> {"=", result, "-", counterId}; 
    addQuad(tempQuad);

    tempQuad = std::vector<std::string> {"GOTO", "-", "-", std::to_string(returnStart)}; 
    addQuad(tempQuad);

    fillGotoQuad(end, quadPtr); 
}

// FUNCIONES
// 7
void Quad::addEndFunc() {
    std::vector<std::string> tempQuad {"ENDFUNC", "-", "-", "-"}; 
    addQuad(tempQuad);
}

// 2
void Quad::generateEra(const std::string funcId) {
    std::vector<std::string> tempQuad {"ERA", funcId, "-", "-"}; 
    addFalseBottom(); 
    addQuad(tempQuad);
}

// 3
void Quad::generateParameter(const std::string argument, const std::string paramArg) {
    std::vector<std::string> tempQuad {"PARAMETER", argument, "-", paramArg}; 
    addQuad(tempQuad);
}

// 6
void Quad::addGoSub(const std::string funcId, int quadLoc) {
    std::vector<std::string> tempQuad {"GOSUB", funcId, "-", std::to_string(quadLoc)}; 
    removeFalseBottom();
    addQuad(tempQuad);
}

// RETORNO FUNCIONES
// 1
void Quad::saveReturnValue(const std::string returnValue) {
    std::vector<std::string> tempQuad {"RETURN", (*tablasDatos).currentFunc, "-", returnValue}; 
    addQuad(tempQuad);
}

// 2
void Quad::addReturnValue(const std::string funcId, const std::string returnType) {
    std::string temp = getNextAvail(returnType);
    // memory: global/local, return type, temp, 
    std::vector<std::string> tempQuad {"=", funcId, "-", temp}; 
    addQuad(tempQuad);

    sOperands.push_back(temp);
    sTypes.push_back(returnType);
}

// MAIN
// 1
void Quad::savePrincipalLoc() {
    sJumps.push_back(quadPtr);

    std::vector<std::string> tempQuad {"GOTO", "principal", "-", "-"}; 
    addQuad(tempQuad);
}

// 3
void Quad::addGotoPrincipalLoc() {
    int principalBegin = sJumps.back();
    sJumps.pop_back();

    fillGotoQuad(principalBegin, quadPtr);
}


// UTILIDAD
std::string Quad::popOperand() {
    if (sOperands.empty()) {
        return "ERROR: funcion no puede regresar operandos. Lista vacia\n";
    }
    std::string temp = sOperands.back();
    sOperands.pop_back();
    return temp;
}

std::string Quad::popType() {
    if (sTypes.empty()) {
        return "ERROR: funcion no puede regresar tipo. Lista vacia\n";
    }
    std::string temp = sTypes.back();
    sTypes.pop_back();
    return temp;
}

int Quad::getQuadCont() const {
    return quadPtr;
}

void Quad::addNewTempCounter() {
    sTemps.push_back(0);
    sTempTypes.push_back({0, 0, 0, 0});
}

std::vector<int> Quad::getCurrentTempTypes() {
    if (sTemps.size() <= 0) {
        std::cout << "ERROR: no temporal counters left\n";
        return {-1};
    }

    int tempsUsed = sTemps.back();
    sTemps.pop_back();

    std::vector<int> tempTypes = sTempTypes.back();
    sTempTypes.pop_back();

    return tempTypes;
}

void Quad::printData() {
    std::cout << "\n---------\n";
    int quadCounter = 0;
    
    for (auto quad : quads) {
        std::cout << quadCounter++ << " " << quad[0] <<  ", " << quad[1] <<  ", " << quad[2] <<  ", " << quad[3] <<  "\n";
    }

    std::cout << "\n---------\n";
    quadCounter = 0;
    for (auto quad : memQuads) {
        std::cout << quadCounter++ << " " << quad[0] <<  ", " << quad[1] <<  ", " << quad[2] <<  ", " << quad[3] <<  "\n";
    }

    std::cout << "Operators left in stack: " << sOperators.size() << " - ";
    while(!sOperators.empty()) {
        std::cout << sOperators.back() << ", ";
        sOperators.pop_back();
    }
    std::cout << "Operands left in stack: " << sOperands.size() << " - ";
    while(!sOperands.empty()) {
        std::cout << sOperands.back() << ", ";
        sOperands.pop_back();
    }
    std::cout << "\nQuad ptr: " << quadPtr << "\n";
    std::cout << "\n---------\n";
}