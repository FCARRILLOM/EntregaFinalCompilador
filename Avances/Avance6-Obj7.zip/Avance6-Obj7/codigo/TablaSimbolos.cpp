#include "TablaSimbolos.h"
#include <iostream>
#include <algorithm>

void TablaSimbolos::addVarsToDir(std::string funcId, std::vector<VarEntry> vars) {
   // mapea todas las variables dentro del directorio de variables
   if ((*funcDir)[funcId].varDir == nullptr) {
      std::cout << "ERROR: Empty variable directory for function: " << funcId << "\n";
      return;
   }

   for (VarEntry var : vars) {
     (*(*funcDir)[funcId].varDir)[var.varName] = var;
   }
}

///// VARIABLES DECLARADAS DENTRO DEL BLOQUE (variables ...) /////
// 1
void TablaSimbolos::initVarsForDir() {
   currVarNames.clear(); 
   varsForDir.clear();         
}

// 2
void TablaSimbolos::saveCurrVars(const std::string varType) {
   for (std::string varName : currVarNames) {
      int memAddr = -1;
      std::string scope = "local";
      // memory: can be local or global, type, non temp
      if (currentFuncDecl == "main") scope = "global";

      switch (cubo.typeMap[varType]) {
         case 0:
            memAddr = memoria->reserveIntMemory(scope, false);
            break;
         case 1:
            memAddr = memoria->reserveFloatMemory(scope, false);
            break;
         case 2:
            memAddr = memoria->reserveCharMemory(scope);
            break;
      }

      if (memAddr == -1) {
         std::cout << "ERROR: cannot reserve space for variable " + varName + "\n";
      }

     varsForDir.push_back(VarEntry {varName, varType, memAddr});
   }
   currVarNames.clear();
}

// 3
void TablaSimbolos::addToCurrVarNames(const std::string varName) {
   if (std::find(currVarNames.begin(), currVarNames.end(), varName) != currVarNames.end()) {
      std::cout << "ERROR: redeclaration of local variable named '" + varName + "'\n";
      return;
   }

   for (VarEntry par : parameters) {
      if (par.varName == varName) {
         std::cout << "ERROR: redeclaration of function parameter named '" + varName + "'\n";
         return;
      }
   }

   currVarNames.push_back(varName);
}

///// VARIABLES DECLARADAS COMO PARAMETROS EN FUNCIONES /////
// 1
void TablaSimbolos::initParameterVars() {
   parameters.clear();
}

// 2
void TablaSimbolos::addParameterVar(std::string varName, std::string varType) {
   // check existing variable name in parameter
   for (VarEntry par : parameters) {
      if (par.varName == varName) {
         std::cout << "ERROR: redeclaration of parameter named '" + varName + "'\n";
         return;
      }
   }

   int memAddr = -1;
   // memory: local, type, not temp variable
   switch (cubo.typeMap[varType]) {
      case 0:
         memAddr = memoria->reserveIntMemory("local", false);
         break;
      case 1:
         memAddr = memoria->reserveFloatMemory("local", false);
         break;
      case 2:
         memAddr = memoria->reserveCharMemory("local");
         break;
   }

   if (memAddr == -1) {
      std::cout << "ERROR: cannot reserve space for parameter var\n";
      return;
   }

   parameters.push_back(VarEntry {varName, varType, memAddr});
}

// DEFINICIONES DE FUNCIONES
int TablaSimbolos::funcExists(const std::string funcId) {
   return((*funcDir).count(funcId));
}

// 1
void TablaSimbolos::createFunc(const std::string funcId, const std::string returnType) {
   if (funcExists(funcId)) { 
      std::cout << "Duplicate function name\n"; 
      return;
   }
   currentFuncDecl = funcId;
   (*tablasDatos).currentFunc = funcId;

   (*funcDir)[funcId] = FuncEntry {funcId, returnType, std::vector<std::string>(), 0, 0, 0, -1,
                                 std::make_unique<std::unordered_map<std::string, VarEntry>>()};

   quad->addNewTempCounter();
}

// 2/3
void TablaSimbolos::addParameterVarsToDir() {
  addVarsToDir(currentFuncDecl, parameters);
  // add parameter types to Parameter table
  for (VarEntry par : parameters) {
     (*funcDir)[currentFuncDecl].parameterTable.push_back(par.varType);
   }
}

// 4
void TablaSimbolos::addNumParameters() {
   (*funcDir)[currentFuncDecl].numPar = parameters.size();
}

// 5 from FUNCIONES
void TablaSimbolos::addCurrLVarsToDir() {
   addVarsToDir(currentFuncDecl, varsForDir);
   (*funcDir)[currentFuncDecl].numLVar = varsForDir.size();
}

// 6
void TablaSimbolos::addFuncCont() {
   (*funcDir)[currentFuncDecl].quadCont = quad->getQuadCont();
}

// 7
void TablaSimbolos::addEndFunc() {
   /*
   std::cout << currentFuncDecl << "-----\n";
   for (auto &v_entry : *((*funcDir)[currentFuncDecl].varDir)) {
      std::cout << v_entry.second.memoryAddr << " " << v_entry.second.varType << ": " << v_entry.second.varName << "\n";
   }
   std::cout << std::endl;
   */
   (*funcDir)[currentFuncDecl].varDir.reset();
   (*funcDir)[currentFuncDecl].numTemp = quad->getCurrentTempCounter();
   memoria->resetLocalMemory();
   quad->addEndFunc();
}

// LLAMADAS DE FUNCIONES
// 1
void TablaSimbolos::verifyFunction(const std::string funcId) {
   if ((*funcDir).count(funcId) == 0) {
      std::cout << "ERROR: " + funcId + " no existe\n";
   }
   functionCalls.push_back(funcId);
}

// 2
void TablaSimbolos::generateEra() {
   parameterCounter = 0;
   quad->generateEra(functionCalls.back());
}

// 3
void TablaSimbolos::verifyParameterType() {
   std::string argument = quad->popOperand();
   std::string argumentType = quad->popType();
   std::string currentFunc = functionCalls.back();

   if (parameterCounter < (*funcDir)[currentFunc].parameterTable.size()) {
      if (argumentType != (*funcDir)[currentFunc].parameterTable[parameterCounter]) {
         std::cout << "ERROR: mismatching parameter types for func '" + currentFunc + "'\n";
         std::cout << "Given type: " + argumentType + ", expected type: " + (*funcDir)[currentFunc].parameterTable[parameterCounter] + "\n";
         return;
      }

      quad->generateParameter(argument, "param" + std::to_string(parameterCounter));

   } else {
      std::cout << "ERROR: extraneous parameters for func '" + currentFunc + "'\n";
   }
}

// 4
void TablaSimbolos::moveToNextParam(){
   parameterCounter += 1;
}

// 5
void TablaSimbolos::verifyLastParam(){
   if (parameterCounter != (*funcDir)[functionCalls.back()].parameterTable.size()) {
      std::cout << "ERROR: coherence in number of parameters for function call '" + functionCalls.back() + "'\n";
   }
}

// 6
void TablaSimbolos::addGoSub(){
   std::string currentFunc = functionCalls.back();
   quad->addGoSub(currentFunc, (*funcDir)[currentFunc].quadCont);
   // se puede hacer pop aqui porque no necesitamos guardar el funcId para obtener su valor de retorno mas adelante
   if ((*funcDir)[currentFunc].returnType == "void") functionCalls.pop_back();
}


// MAIN
// 2
void TablaSimbolos::addPrincipalFunc(const std::string principalName) {
   programName = principalName;
   (*tablasDatos).programName = programName;
   (*funcDir)[principalName] = FuncEntry {principalName, "NP", std::vector<std::string>(), 0, 0, 0, 0,
                                 std::make_unique<std::unordered_map<std::string, VarEntry>>()};
   
   quad->addNewTempCounter();
}

// 4
void TablaSimbolos::saveGlobalVars() {
   // TODO: check for duplicate var names
   addVarsToDir(programName, varsForDir);
   (*funcDir)[programName].numLVar += varsForDir.size();
   initVarsForDir();
}

// 5
void TablaSimbolos::addFuncGlobalVar() {
   if ((*funcDir)[currentFuncDecl].returnType == "void") {
      currentFuncDecl = "main";
      return;
   }

   // mapea todas las variables dentro del directorio de variables
   if ((*funcDir)[programName].varDir == nullptr) {
      std::cout << "ERROR: Empty variable directory for function: " << programName << "\n";
      return;
   }

   int memAddr = -1;
   // memory: global, returntype, not temp
   switch (cubo.typeMap[(*funcDir)[currentFuncDecl].returnType]) {
      case 0:
         memAddr = memoria->reserveIntMemory("global", false);
         break;
      case 1:
         memAddr = memoria->reserveFloatMemory("global", false);
         break;
      case 2:
         memAddr = memoria->reserveCharMemory("global");
         break;
   }

   if (memAddr == -1) {
      std::cout << "ERROR: cannot reserve space for function var\n";
      return;
   }
   
   VarEntry var { currentFuncDecl, (*funcDir)[currentFuncDecl].returnType, memAddr };
   (*(*funcDir)[programName].varDir)[var.varName] = var;

   (*funcDir)[programName].numLVar++;

   currentFuncDecl = "main";
   (*tablasDatos).currentFunc = "main";
}

// 6
void TablaSimbolos::saveTempsUsed() {
   /*
   std::cout << "MAIN ---\n";
   for (auto &v_entry : *((*funcDir)[programName].varDir)) {
      std::cout << v_entry.second.memoryAddr << " " << v_entry.second.varType << ": " << v_entry.second.varName << "\n";
   }
   */
   std::cout << std::endl;
   (*funcDir)[programName].numTemp = quad->getCurrentTempCounter();
}

// RETORNO
// 1 - retorno en declaracion de una funcion
void TablaSimbolos::saveReturnValue() {
   std::string result = quad->popOperand();
   std::string resultType = quad->popType();

   if (result.substr(0, 3) != "err") {
      if (resultType != (*funcDir)[currentFuncDecl].returnType) {
         std::cout << "ERROR: function return type not valid for function '" + currentFuncDecl + "'\n";
      } else {
         quad->saveReturnValue(result);
         //TODO: Save result in funcName global variable
      }
   } else {
      std::cout << result;
   }
}

// 2 - retorno despues de terminar llamada a una funcion que retorna un valor
void TablaSimbolos::addReturnValue() {
   std::string currentFunc = functionCalls.back();
   quad->addReturnValue(currentFunc, (*funcDir)[currentFunc].returnType);
   functionCalls.pop_back();
}


void TablaSimbolos::printData() {
   std::cout << "FUNC_DIR\n";
   for (auto &f_entry : (*funcDir)) {

     std::cout << f_entry.second.quadCont << " " << f_entry.first << ": " << f_entry.second.returnType << "\n";
     std::cout << "Signature (" << f_entry.second.numPar << " params): ";
     for (std::string par : f_entry.second.parameterTable) {
        std::cout << par << ", ";
     }

     std::cout << "\nTemps used (" << f_entry.second.numTemp << ") - ";
     std::cout << "\nLocal vars (" << f_entry.second.numLVar << ") - ";
     
     if (f_entry.second.varDir) {
       for (auto &v_entry : *(f_entry.second.varDir)) {
         std::cout << v_entry.second.varType << ": " << v_entry.second.varName << ", ";
       }
     }
     
     std::cout << "\n\n";
   }
   
}
