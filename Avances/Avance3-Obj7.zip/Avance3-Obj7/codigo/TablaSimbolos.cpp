#include "TablaSimbolos.h"
#include <iostream>

int TablaSimbolos::funcExists(std::string funcId) {
   return(funcDir.count(funcId));
}

void TablaSimbolos::createFunc(std::string funcId, std::string returnType) {
   // check for existing funcId
   if (funcExists(funcId)) return;
   funcDir[funcId] = FuncEntry {funcId, returnType, new std::unordered_map<std::string, VarEntry>};
}

void TablaSimbolos::addVarsToDir(std::string funcId, std::vector<VarEntry> vars) {
   // mapea todas las variables dentro del directorio de variables
   for (VarEntry var : vars) {
     (*funcDir[funcId].varDir)[var.varName] = var;
   }
}

///// VARIABLES DECLARADAS DENTRO DEL BLOQUE (variables ...) /////
void TablaSimbolos::initVarsForDir() {
   currVarNames.clear(); 
   varsForDir.clear();         
}

void TablaSimbolos::addToCurrVarNames(std::string varName) {
   currVarNames.push_back(varName);
}

void TablaSimbolos::saveCurrVars(std::string varType) {
   for (std::string varName : currVarNames) {
     varsForDir.push_back(VarEntry {varName, varType});
   }
   currVarNames.clear();
}

void TablaSimbolos::addCurrVarsToDir(std::string funcId) {
   addVarsToDir(funcId, varsForDir);
}

///// VARIABLES DECLARADAS COMO PARAMETROS EN FUNCIONES /////
void TablaSimbolos::initParameterVars() {
   parameters.clear();
}

void TablaSimbolos::addParameterVar(std::string varName, std::string varType) {
   parameters.push_back(VarEntry {varName, varType});
}

void TablaSimbolos::addParameterVarsToDir(std::string funcId) {
  addVarsToDir(funcId, parameters);
}


void TablaSimbolos::printData() {
   std::cout << "FuncDir\n";
   for (auto f_entry : funcDir) {
     std::cout << f_entry.first << ": " << f_entry.second.returnType << ", ";
     if (f_entry.second.varDir) {
       std::cout << "Vars - ";
       for (auto v_entry : *(f_entry.second.varDir)) {
         std::cout << v_entry.second.varType << ": " << v_entry.second.varName << ", ";
       }
     }
     std::cout << "\n\n";
   }
   
}
