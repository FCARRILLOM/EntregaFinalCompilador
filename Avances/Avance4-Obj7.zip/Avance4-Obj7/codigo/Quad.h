#ifndef QUAD_H
#define QUAD_H

#include <string>
#include <iostream>
#include <vector>

#include "CuboSemantico.h"

class Quad {
private:
    CuboSemantico cubo;

    // vectores que simulan Stacks
    std::vector<std::string> sOperators;
    std::vector<std::string> sOperands;
    std::vector<std::string> sTypes;
    std::vector<int> sJumps;

    // vector que simula Queue donde se guardan los quadruplos generados
    std::vector<std::vector<std::string>> quads;

    // guarda los valores generados en el proceso de construccion de quadruplos
    // ej. 't1', 't2', ...
    std::vector<std::string> avail;

    // contador que se utiliza para generar el valor que representa 'result' en los quadruplos
    int availCounter;

    // apuntador
    int quadPtr;

    // adds a quad to quad list and increments quad counter
    void addQuad(const std::vector<std::string> quad);

    // removes two operands and a binary arithmetic operator to generate quad, ex. +, A, B, t1
    void addArithmeticQuad();

    // removes one operand and an assign operator, ex. =, A, -, B
    void addAssignQuad();

    // retorna siguiente valor disponible e incrementa el contador del avail
    std::string getNextAvail();

    // fills an existing Goto quad with a pending position
    void fillGotoQuad(int position, int newValue);

public:
    Quad() {
        quadPtr = 0;
    }

    // elimina los datos previos de los stacks y vector de quadruplos para empezar el proceso de nuevo
    void clearQuad();

    // REGLAS ARITMETICAS tomadas del documento Exp PN and Quad, donde se describen las reglas para generar los cuadruplos
    // de las expresiones aritmeticas
    // 1
    void addOperand(const std::string name, std::string type);

    // 2
    void addOperatorPlusMinus(const std::string op);

    // 3
    void addOperatorMultDiv(const std::string op);

    // 4
    void removeFromStackPlusMinus();

    // 5
    void removeFromStackMultDiv();

    // 6
    void addFalseBottom();

    // 7
    void removeFalseBottom();

    // 8
    void addOperatorRel(const std::string op);

    // 9
    void removeFromStackRel();

    // 10
    void addOperatorAnd(const std::string op);

    // 11
    void addOperatorOr(const std::string op);

    // 12
    void removeFromStackAnd();

    // 13
    void removeFromStackOr();

    // 14
    void addOperatorAsig(const std::string op);

    // 15
    void removeFromStackAssign();

    // LECTURA Y ESCRITURA
    // 16
    void addRead(const std::string name);

    // 17
    void addWriteExp();

    // 18
    void addWriteStr(const std::string const_string);

    // DECISIONES
    // 1
    void addGotoIf();

    // 2
    void addDecisionEnd();

    // 3
    void addGotoElse();

    // CONDICIONALES
    // 1
    void addWhileCheckpoint();

    // 2
    void addGotoWhile();

    // 3
    void addConditionalEnd();

    void printData();

    // NO CONDICIONALES
    // 1
    void addLoopCounter(const std::string counterId);

    // 2
    void addLoopLimit();

    // 3
    void addGotoFor();

    // 4
    void addNonConditionalEnd(const std::string counterId);

};

#endif