#ifndef TABLA_SIMBOLOS_H
#define TABLA_SIMBOLOS_H

#include <unordered_map>
#include <string>
#include <vector>
#include <stack>

struct VarEntry {
   std::string varName;
   std::string varType;
};

struct FuncEntry {
   std::string funcName;
   std::string returnType;
   std::unordered_map<std::string, VarEntry>* varDir;
};

class TablaSimbolos {
private:
   // directorio de funciones
   std::unordered_map<std::string, FuncEntry> funcDir;

   // vector para guardar los parametros declarados en la definicion de una funcion 
   // ej. int funcion f1(int: x, int y);
   std::vector<VarEntry> parameters;

   // vector para guardar las variables que son declaradas en bloque VARIABLES dentro de una funcion
   // ej. variables ...
   std::vector<VarEntry> varsForDir;
   // variables declaradas en un mismo renglon para un mismo tipo por ser agregadas a varsForDir
   // ej. int var1, var2, var2;
   std::vector<std::string> currVarNames;

public:
   TablaSimbolos(){
   }

   // Inidica si ya existe una funcion en el directorio de funciones con un id
   int funcExists(std::string funcId);

   // Crea una entrada en el directorio de funciones
   void createFunc(std::string funcId, std::string returnType);

   // Agrega variables a la tabla de variables de una funcion
   void addVarsToDir(std::string funcId, std::vector<VarEntry> vars);
   
   // Inicializa vector donde se guardaran las variables a declaradas con su respectivo tipo 
   // para despues ser agregadas al directorio de variables
   void initVarsForDir();

   // Agrega el nombre de una variable a la lista de variables declaradas para un tipo en bloque VARIABLES
   void addToCurrVarNames(std::string varName);

   // Agrega variables declaradas con su tipo al vector varsForDir
   void saveCurrVars(std::string varType);

   // Agrega las variables declaradas a la tabla de variables de su respectiva funcion
   void addCurrVarsToDir(std::string funcId);

   // Inicializa vector para guardar parametros declarados en la definicion de una funcion
   void initParameterVars();

   // Agrega variable a lista actual de variables locales (parametros) para una funcion
   void addParameterVar(std::string varName, std::string varType);

   // Agrega las variables parametro en la tabla de variables de su respectiva funcion
   void addParameterVarsToDir(std::string funcId);

   // Imprime directorio de funciones
   void printData();
};

#endif