Equipo Obj7
Fernando Carrillo
Lucia Cantu-Miller

Avances:
- 08/04/21 Implementación de tokens y gramática descritos en el documento con los diagramas
- 16/04/21 Implementación de Directorio de funciones y tablas de variables. Las funciones son agregadas junto con su tipo al directorio, 
            y las variables son agregadas a las tablas de su respectivo scope junto con su tipo.
- 23/04/21 Implementación de Cubo Semántico y generación de cuádruplos para operaciones aritméticas con variables (sin tipo) y valores cte.
- 25/04/21 Generación de código para estatutos lineales (asignación, lectura, escritura)
- 30/04/21 Generacion de código para estatutos condicionales (If/else, while, for)
- 08/04/21 Generacion de código para declaracion de funciones y llamadas a funciones. Falta hacer la creacion de memoria ERA size.

Pendiente:
- Investigar y arreglar warnings de shift/reduce reduce/reduce
- Arreglar detalle de asignación a chars se toman como ints

Cambios personales a la descripción original del proyecto
- En lugar de llamar los tipos en español 'entero, flotante', se cambiaron a inglés 'int, float'
- En lugar de declarar las variables como 'ids : tipo', se cambio el orden a 'tipo : ids'


Para correr el parser:
- Abrir la terminal y navegar al folder donde se encuentra el código
- Correr el comando 'make' para generar el ejecutable 'parser'
- Insertar un documento txt al parser corriendo el comando './parser < (tuArchivo).txt'
- Si hay un error sintáctico en el código, aparecerá un mensaje de error indicando la linea donde se encuentra este

