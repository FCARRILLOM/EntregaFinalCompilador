#ifndef TABLA_SIMBOLOS_H
#define TABLA_SIMBOLOS_H

#include <unordered_map>
#include <string>
#include <vector>
#include <stack>
#include <memory>

#include "Quad.h"

struct VarEntry {
   std::string varName;
   std::string varType;
};

struct FuncEntry {
   std::string funcName;
   std::string returnType;
   std::vector<std::string> parameterTable; // signature of parameter types
   int numPar; // number of parameter variables
   int numLVar; // number of local variables
   int quadCont; // quad counter where it begins
   std::unique_ptr<std::unordered_map<std::string, VarEntry>> varDir;
};

class TablaSimbolos {
private:
   // directorio de funciones
   std::unordered_map<std::string, FuncEntry> funcDir;

   std::string currentFunctionCall;

   // vector para guardar los parametros declarados en la definicion de una funcion 
   // ej. int funcion f1(int: x, int y);
   std::vector<VarEntry> parameters;

   int parameterCounter;

   // vector para guardar las variables que son declaradas en bloque VARIABLES dentro de una funcion
   // ej. variables ...
   std::vector<VarEntry> varsForDir;
   // variables declaradas en un mismo renglon para un mismo tipo por ser agregadas a varsForDir
   // ej. int var1, var2, var2;
   std::vector<std::string> currVarNames;

public:
   TablaSimbolos(){
   }

   // Inidica si ya existe una funcion en el directorio de funciones con un id
   int funcExists(const std::string funcId);

   // Crea una entrada en el directorio de funciones
   // 1
   void createFunc(const std::string funcId, const std::string returnType);

   // Agrega variables a la tabla de variables de una funcion
   void addVarsToDir(std::string funcId, std::vector<VarEntry> vars);
   
   ///// VARIABLES DECLARADAS DENTRO DEL BLOQUE (variables ...) /////
   // Inicializa vector donde se guardaran las variables a declaradas con su respectivo tipo 
   // para despues ser agregadas al directorio de variables
   void initVarsForDir();

   // Agrega el nombre de una variable a la lista de variables declaradas para un tipo en bloque VARIABLES
   void addToCurrVarNames(const std::string varName);

   // Agrega variables declaradas con su tipo al vector varsForDir
   void saveCurrVars(const std::string varType);

   // Agrega todas las variables declaradas a la tabla de variables de su respectiva funcion
   void addCurrVarsToDir(const std::string funcId);
   
   ///// VARIABLES DECLARADAS COMO PARAMETROS EN FUNCIONES /////
   // Inicializa vector para guardar parametros declarados en la definicion de una funcion
   void initParameterVars();

   // Agrega variable a lista actual de variables locales (parametros) para una funcion
   void addParameterVar(std::string varName, std::string varType);

   // DEFINICION DE FUNCIONES
   // Agrega las variables parametro en la tabla de variables de su respectiva funcion
   // 2/3
   void addParameterVarsToDir(const std::string funcId);

   // 4
   void addNumParameters(const std::string funcId);

   // 5
   void addNumLocalVars(const std::string funcId);

   // 6
   void addFuncCont(const std::string funcId, const Quad &quad);

   // 7
   void addEndFunc(const std::string funcId, Quad &quad);

   // LLAMADAS DE FUNCIONES
   // 1
   void verifyFunction(const std::string funcId);

   // 2
   void generateEra(Quad &quad);

   // 3
   void verifyParameterType(Quad &quad);

   // 4
   void moveToNextParam();

   // 5
   void verifyLastParam();

   // 6
   void addGoSub(Quad &quad);

   // Imprime directorio de funciones
   void printData();
};

#endif