#ifndef QUAD_H
#define QUAD_H

#include <string>
#include <iostream>
#include <vector>

#include "CuboSemantico.h"

CuboSemantico cubo;

class Quad {
private:
    // vectores que simulan Stacks
    std::vector<std::string> sOperators;
    std::vector<std::string> sOperands;
    std::vector<std::string> sTypes;

    // vector que simula Queue donde se guardan los quadruplos generados
    std::vector<std::vector<std::string>> quads;

    // guarda los valores generados en el proceso de construccion de quadruplos
    // ej. 't1', 't2', ...
    std::vector<std::string> avail;
    // contador que se utiliza para generar el valor que representa 'result' en los quadruplos
    int availCounter;

    // retorna siguiente valor disponible e incrementa el contador
    std::string getNextAvail() {
        avail.push_back("t" + std::to_string(availCounter++));
        return avail.back();
    }

    // remove two operands and an operator to generate quad
    void addQuad() {
        std::string left_operand = sOperands.back();
        sOperands.pop_back();
        std::string left_type = sTypes.back();
        sTypes.pop_back();

        std::string right_operand = sOperands.back();
        sOperands.pop_back();
        std::string right_type = sTypes.back();
        sTypes.pop_back();

        std::string op = sOperators.back();
        sOperators.pop_back();

        std::string resultType = cubo.getTypeFromCube(left_type, right_type, op);
        //std::cout << left_operand << ":" << left_type << ", " << right_operand << ":" << right_type << ", " << op << ", " << resultType << std::endl;
        if (resultType.substr(0, 3) != "err") {
            std::string result = getNextAvail();
            std::vector<std::string> tempQuad {op, left_operand, right_operand, result};
            quads.push_back(tempQuad);
            sOperands.push_back(result);
            sTypes.push_back(resultType);
            // If any operand were a temporal space, return it to AVAIL ???
        } else {
            std::cout << resultType << std::endl;
        }
    }

public:
    // elimina los datos previos de los stacks y vector de quadruplos para empezar el proceso de nuevo
    void initQuad() {
        sOperators.clear();
        sOperands.clear();
        sTypes.clear();
        quads.clear();
        avail.clear();
        availCounter = 1;
    }

    // 1
    void addOperand(const std::string name, std::string type) {
        sOperands.push_back(name);
        sTypes.push_back(type);
    }

    // 2
    void addOperatorPlusMinus(const std::string op) {
        sOperators.push_back(op);
    }

    // 3
    void addOperatorMultDiv(const std::string op) {
        sOperators.push_back(op);
    }

    // 4
    void removeFromStackPlusMinus() {
        if (sOperators.empty()) return;

        if (sOperators.back() == "+" || sOperators.back() == "-") {
            addQuad();
        }
    }

    // 5
    void removeFromStackMultDiv() {
        if (sOperators.empty()) return;

        if (sOperators.back() == "*" || sOperators.back() == "/") {
            addQuad();
        }
    }

    // 6
    void addFalseBottom() {
        sOperators.push_back("[");
    }

    // 7
    void removeFalseBottom() {
        sOperators.pop_back();
    }

    // 8
    void addOperatorRel(const std::string op) {
        sOperators.push_back(op);
    }

    // 9
    void removeFromStackRel() {
        if (sOperators.empty()) return;
        
        std::string relOps = ">,<,>=,<=,<>,==";
        if (relOps.find(sOperators.back()) != std::string::npos) {
            addQuad();
        }
    }

    // 10
    void addOperatorAnd(const std::string op) {
        sOperators.push_back(op);
    }

    // 11
    void addOperatorOr(const std::string op) {
        sOperators.push_back(op);
    }

    // 12
    void removeFromStackAnd() {
        if (sOperators.empty()) return;

        if (sOperators.back() == "&") {
            addQuad();
        }
    }

    // 13
    void removeFromStackOr() {
        if (sOperators.empty()) return;

        if (sOperators.back() == "|") {
            addQuad();
        }
    }

    void printData() {
        for (auto quad : quads) {
            std::cout << quad[0] <<  ", " << quad[1] <<  ", " << quad[2] <<  ", " << quad[3] <<  "\n";
        }
        std::cout << "Operators left in stack: " << sOperators.size() << " - ";
        while(!sOperators.empty()) {
            std::cout << sOperators.back() << ", ";
            sOperators.pop_back();
        }
        std::cout << "Operands left in stack: " << sOperands.size() << " - ";
        while(!sOperands.empty()) {
            std::cout << sOperands.back() << ", ";
            sOperands.pop_back();
        }
        std::cout << "\n---------\n";
    }

};

#endif